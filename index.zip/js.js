




function start () {

    alert("Hi, My freind")
    
}